export class contact{
    firstname: string;
    lastname: string;
    mobile: string;
}