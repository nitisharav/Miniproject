import { Injectable } from '@angular/core';
import { contact } from './contact';
//import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ContactsService {
  constructor() { }

  contacts: contact[]=[
    { firstname: 'Peter', lastname:'Parker', mobile:'9876582310'},
    { firstname: 'Doctor', lastname: 'Strange', mobile: '9876543210'},
    { firstname: 'Captain', lastname: 'America', mobile: '9638521470'}
    
  ];
  ContactsService: any;
getContacts():contact[]{
  return this.contacts;
}
delete(value: contact){
  

  let index = this.contacts.indexOf(value);
  this.contacts.splice(index, 1);
}
// addContacts(fisrtName:string,lastName:string,Mobile:string) { 
//   let newContact= { firstname: fisrtName, lastname:lastName, mobile: Mobile };
//    return this.contacts.push(newContact);
//  }
// addContacts(firstName: string, lastName: string, mobile: string) {
//   this.ContactsService.push(firstName, lastName, mobile);
// }

addContacts(firstName,lastName,mobileno){
  this.contacts.push({firstname:firstName,lastname:lastName,mobile:mobileno});
  alert("New Contact Added Successfully");
  
  console.log("added")
}
}

