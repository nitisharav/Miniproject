import { Component, OnInit } from '@angular/core';
import { ContactsService } from '../contact.service';



@Component({
  selector: 'app-add-contac',
  templateUrl: './add-contact.component.html',
  styleUrls: ['./add-contact.component.css']
})
export class AddContactComponent implements OnInit {

  //addForm:FormGroup;
  constructor( private _contactService: ContactsService) { }

  ngOnInit(): void {
    // this.addForm=this.formBuilder.group({
    
    //   firstName:["",Validators.required],
    //   lastName:["",Validators.required],
    //   mobile:["", Validators.required]
    // })
  }
  // onSubmit(form){
  //    this.contactService.addContacts(form.value).subscribe(data =>{
  //     console.log(data)
  //      alert("user added successfully");
  //    });
  // }
  addContacts(fname: any,lname: any,num: any){
    this._contactService.addContacts(fname,lname,num);
  }


}
