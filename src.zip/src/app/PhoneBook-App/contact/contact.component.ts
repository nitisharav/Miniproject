
import { Component, OnInit } from '@angular/core';


import { Router } from '@angular/router';
import { contact } from '../contact';
import { ContactsService } from '../contact.service';


@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit {
  contacts: contact[]=[];
  searchbox: String= "";
  forLoop: String = "let contact of contacts";
  showModal: boolean;
  title = 'angularpopup';
   //showModal: boolean;
   submitted = false;
   showDetails: boolean;
   searchKey : String;
  searchText : String;
  
 
  constructor(private contactService: ContactsService,  private _router: Router) {
    
    //this.contacts = new contact();
    this.contacts= this.contactService.getContacts();

  }
   show()
   {
    this.showModal = true;

   }
  
  hide()
   {
     this.showModal = false;
   }
  
  
  addContacts() {
    this._router.navigate(['add-contact']);
  }
  deleteDetails(value:contact){

    this.contactService.delete(value);
  }
  
     onClose() 
 {

 }
 onSortbyName()
     {
       this.contacts.sort((a, b) => (a.firstname < b.firstname ? -1 : 1));
     }
 onSortbyNumber()
{
     this.contacts.sort((a, b) => (a.mobile < b.mobile ? -1 : 1));
 }

editDetails(mobile){
  this._router.navigate(['edit-user',mobile]);

}



 

  ngOnInit(): void {
   this.contacts= this.contactService.getContacts();

  }
}